-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Czas generowania: 05 Kwi 2024, 20:46
-- Wersja serwera: 10.4.24-MariaDB
-- Wersja PHP: 8.1.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Baza danych: `kawiarnia`
--

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `klienci`
--

CREATE TABLE `klienci` (
  `KlientID` int(11) NOT NULL,
  `ImieNazwisko` varchar(50) DEFAULT NULL,
  `Telefon` varchar(20) DEFAULT NULL,
  `Email` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;


-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `kontakt`
--

CREATE TABLE `kontakt` (
  `KontaktID` int(11) NOT NULL,
  `KlientID` int(11) NOT NULL,
  `Tresc` varchar(400) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;


-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `koszyk`
--

CREATE TABLE `koszyk` (
  `KoszykID` int(11) NOT NULL,
  `KlientID` int(11) NOT NULL,
  `ProduktyID` int(11) NOT NULL,
  `Ilosc` int(11) NOT NULL,
  `Adres` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `produkty`
--

CREATE TABLE `produkty` (
  `ProduktyID` int(11) NOT NULL,
  `Nazwa` varchar(60) NOT NULL,
  `Cena` int(2) NOT NULL,
  `Obraz` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Zrzut danych tabeli `produkty`
--

INSERT INTO `produkty` (`ProduktyID`, `Nazwa`, `Cena`, `Obraz`) VALUES
(1, 'Sernik', 15, './assets/sernik.jpg'),
(2, 'Szarlotka', 20, './assets/szarlotka.jpg'),
(3, 'Torcik', 16, './assets/torcik.jpg'),
(4, 'Tiramisu', 18, './assets/tiramisu.jpg'),
(5, 'Spaghetti', 23, './assets/spaghetti.jpg'),
(6, 'Schabowy', 26, './assets/schab.jpg'),
(7, 'Rosół', 12, './assets/rosol.jpg'),
(8, 'Żurek', 15, './assets/zurek.jpg'),
(9, 'Cynamon-wanilia', 10, './assets/kawaCW.jpg'),
(10, 'Frappuccino', 13, './assets/frappuccino.jpg'),
(11, 'Latte', 8, './assets/latte.jpeg'),
(12, 'Mocca', 12, './assets/mocca.jpg');

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `rezerwacje`
--

CREATE TABLE `rezerwacje` (
  `RezerwacjaID` int(11) NOT NULL,
  `KlientID` int(11) DEFAULT NULL,
  `StolikID` int(11) DEFAULT NULL,
  `DataRezerwacji` date DEFAULT NULL,
  `Godzina` time DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Zrzut danych tabeli `rezerwacje`
--


-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `stoliki`
--

CREATE TABLE `stoliki` (
  `StolikID` int(11) NOT NULL,
  `NumerStolika` int(11) DEFAULT NULL,
  `IloscMiejsc` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Zrzut danych tabeli `stoliki`
--

INSERT INTO `stoliki` (`StolikID`, `NumerStolika`, `IloscMiejsc`) VALUES
(1, 1, 4),
(2, 2, 2),
(3, 3, 6),
(4, 4, 4),
(5, 5, 3);

--
-- Indeksy dla zrzutów tabel
--

--
-- Indeksy dla tabeli `klienci`
--
ALTER TABLE `klienci`
  ADD PRIMARY KEY (`KlientID`);

--
-- Indeksy dla tabeli `kontakt`
--
ALTER TABLE `kontakt`
  ADD PRIMARY KEY (`KontaktID`),
  ADD KEY `KlientID` (`KlientID`);

--
-- Indeksy dla tabeli `koszyk`
--
ALTER TABLE `koszyk`
  ADD PRIMARY KEY (`KoszykID`),
  ADD KEY `KlientID` (`KlientID`),
  ADD KEY `ProduktyID` (`ProduktyID`);

--
-- Indeksy dla tabeli `produkty`
--
ALTER TABLE `produkty`
  ADD PRIMARY KEY (`ProduktyID`);

--
-- Indeksy dla tabeli `rezerwacje`
--
ALTER TABLE `rezerwacje`
  ADD PRIMARY KEY (`RezerwacjaID`),
  ADD KEY `KlientID` (`KlientID`),
  ADD KEY `NumerStolika` (`StolikID`);

--
-- Indeksy dla tabeli `stoliki`
--
ALTER TABLE `stoliki`
  ADD PRIMARY KEY (`StolikID`);

--
-- AUTO_INCREMENT dla zrzuconych tabel
--

--
-- AUTO_INCREMENT dla tabeli `klienci`
--
ALTER TABLE `klienci`
  MODIFY `KlientID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT dla tabeli `kontakt`
--
ALTER TABLE `kontakt`
  MODIFY `KontaktID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT dla tabeli `koszyk`
--
ALTER TABLE `koszyk`
  MODIFY `KoszykID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT dla tabeli `produkty`
--
ALTER TABLE `produkty`
  MODIFY `ProduktyID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT dla tabeli `rezerwacje`
--
ALTER TABLE `rezerwacje`
  MODIFY `RezerwacjaID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT dla tabeli `stoliki`
--
ALTER TABLE `stoliki`
  MODIFY `StolikID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- Ograniczenia dla zrzutów tabel
--

--
-- Ograniczenia dla tabeli `kontakt`
--
ALTER TABLE `kontakt`
  ADD CONSTRAINT `kontakt_ibfk_1` FOREIGN KEY (`KlientID`) REFERENCES `klienci` (`KlientID`);

--
-- Ograniczenia dla tabeli `koszyk`
--
ALTER TABLE `koszyk`
  ADD CONSTRAINT `koszyk_ibfk_1` FOREIGN KEY (`ProduktyID`) REFERENCES `produkty` (`ProduktyID`),
  ADD CONSTRAINT `koszyk_ibfk_2` FOREIGN KEY (`KlientID`) REFERENCES `klienci` (`KlientID`);

--
-- Ograniczenia dla tabeli `rezerwacje`
--
ALTER TABLE `rezerwacje`
  ADD CONSTRAINT `rezerwacje_ibfk_1` FOREIGN KEY (`KlientID`) REFERENCES `klienci` (`KlientID`),
  ADD CONSTRAINT `rezerwacje_ibfk_2` FOREIGN KEY (`StolikID`) REFERENCES `stoliki` (`StolikID`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
