<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "Kawiarnia";


$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Sprawdzenie, czy formularz został przesłany
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Przechwytywanie danych z formularza
    $imieNazwisko = $_POST['imie'];
    $liczbaOsob = $_POST['liczba_osob'];
    $telefon = $_POST['telefon'];
    $email = $_POST['email'];
    $data = $_POST['data'];
    $godzina = $_POST['godzina'];
    $stolik = $_POST['stolik'];

    // Sprawdzenie, czy klient o podanym imieniu i nazwisku istnieje już w bazie danych
    $sqlCheckClient = "SELECT KlientID FROM Klienci WHERE ImieNazwisko = '$imieNazwisko'";
    $resultCheckClient = $conn->query($sqlCheckClient);

    if ($resultCheckClient->num_rows > 0) {
        $rowClient = $resultCheckClient->fetch_assoc();
        $klientID = $rowClient["KlientID"];
    } else {
        // Dodanie nowego klienta do bazy danych
        $sqlAddClient = "INSERT INTO Klienci (ImieNazwisko, Telefon, Email) VALUES ('$imieNazwisko', '$telefon', '$email')";
        if ($conn->query($sqlAddClient) === TRUE) {
            $klientID = $conn->insert_id;
        }
    }

    // Znalezienie ID stolika na podstawie jego nazwy
    $stolikInt = intval($stolik);
    $sqlStolik = "SELECT StolikID FROM Stoliki WHERE NumerStolika = $stolikInt";
    $resultStolik = $conn->query($sqlStolik);

    if ($resultStolik->num_rows > 0) {
        $rowStolik = $resultStolik->fetch_assoc();
        $numerStolika = $rowStolik["StolikID"];

        // Wstawienie rezerwacji do bazy danych
        $sqlAddReservation = "INSERT INTO Rezerwacje (KlientID, StolikID, DataRezerwacji, Godzina) VALUES ('$klientID', '$numerStolika', '$data', '$godzina')";

        if ($conn->query($sqlAddReservation) === TRUE) {
            header("Location: success.php");
        } 
    }

    // Zamknięcie połączenia z bazą danych
    $conn->close();
}
?>



<!DOCTYPE html>
<html lang="pl-PL">
<head>
    <meta name="title" content="Kawiarnia basic">
    <meta name="description" content="Kolejna typowa kawiarnia w twojej okolicy!">
    <meta name="keywords" content="kawiarnia,kawa,ciasto,piwo,restauracja,jedzenie,picie,tort">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kawiarnia BASIC | Kawa i ciasta</title>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="reservationStyle.css">
    <script src="navScroll.js" defer></script>
    <script src="shoppingcart.js" defer></script>
    <script src="hamburger.js" defer></script>
</head>
<body>
    <!-- navigation -->
    <div class="navbar">
        <div class="logo-box">
            <a href="index.html">
                <img src="./assets/Logo.png" alt="Basic logo" class="logo">
            </a>
        </div>

        <button class="hamburger">
                <div class="bar"></div>
            </button>

            <div class="mobile-nav">
                <a href="menu.html">Menu</a>
                <a href="#">Rezerwacja</a>
                <a href="Shop.php">Sklep</a>
                <a href="about.html">O nas</a>
                <a href="contact.php">Kontakt</a>
                <div class="cart">
                    <a href="#" class="mobile-nav-cart">
                        <img src="./assets/shopping-cart-svgrepo-com.svg" alt="cart" width="50px" class="cart-ico">
                        <p class="cart-number">0</p>
                    </a>
                </div>
            </div>
        </div>
        
        <div class="buttons">
            <a href="menu.html">Menu</a>
            <a href="#">Rezerwacja</a>
            <a href="Shop.php">Sklep</a>
            <a href="about.html">O nas</a>
            <a href="contact.html">Kontakt</a>
            <div class="cart">
            <a href="#">
                <img src="./assets/shopping-cart-svgrepo-com.svg" alt="cart" width="50px" class="cart-ico">
                <p class="cart-number">0</p>
            </a>
        </div>
    </div>
    </div>
    <!-- all other things on the website -->
    <div class="main">
        <div class="reservation-block">
            <h2 class="reservation-Text">Rezerwacja</h2>
            <form class="reservation-form" method="post" action="reservation.php">
                <input type="text" name="imie" placeholder="Imie i nazwisko" required><br>
                <input type="number" name="liczba_osob" placeholder="Liczba osób" min="1" max="10" required><br>
                <input type="tel" name="telefon" placeholder="Telefon" required><br>
                <input type="email" name="email" placeholder="Email" required><br>
                <input type="date" name="data" placeholder="Data" required><br>
                <input type="time" name="godzina" placeholder="Godzina" required><br>
                <select name="stolik" required>
                    <option value="" disabled selected>Wybierz stolik</option>
                    <option value="1">Stolik 1</option>
                    <option value="2">Stolik 2</option>
                    <option value="3">Stolik 3</option>
                    <option value="4">Stolik 4</option>
                    <option value="5">Stolik 5</option>
                </select><br>
                <input type="submit" value="Zarezerwuj">
            </form>
        </div>

    </div>

        <!-- end of site and footer-->
        <div class="footer">
            <div class="background-img">
                <div class="blur">
                    <div class="logo-box">
                        <img src="./assets/Logo.png" alt="Basic logo" class="logo">
                        <div class="logo-texts">
                            <h3 class="logo-text">Kawiarnia BASIC</h3>
                            <p class="logo-paragraph">Wszędzie są takie same. A my niczym się nie wyrózniamy!</p>
                        </div>
                    </div>
                        <div class="footer-links">
                            <h1>Główna</h1>
                            <a href="index.html">BASIC</a>
                            <a href="menu.html">Menu</a>
                            <a href="#">Rezerwacje</a>
                            <a href="#">Zamówienia</a>
                            <a href="shop.php">Sklep</a>
                            <a href="about.html">O nas</a>
                            <a href="#">Polityka Prywatności</a>
                            <a href="#">Regulamin</a>
                        </div>
                        <div class="footer-location">
                            <h1>Lokalizacja</h1>
                            <p>Ulica jakaś tam 1/3</p>
                            <p>Miastowo, 00-000</p>
                        </div>
                        <div class="lorem">
                            <h1>Lorem ipsum</h1>
                            <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Blanditiis fuga obcaecati, accusamus aliquam nam, vitae repellendus iusto temporibus ut, amet placeat!</p>
                        </div>
                        <p class="credit">stronę stworzył Paweł Raducki</p>
                    </div>
                </div>
            </div>
        </div>
    </div>

</body>
</html>


