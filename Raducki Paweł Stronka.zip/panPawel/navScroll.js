var deviceHeight = window.innerHeight;

if (deviceHeight >= 1000) {
    window.addEventListener("scroll", scrollFunction);
    function scrollFunction() {
        var navbar = document.querySelector(".navbar");
        var logo = document.querySelector(".logo");
        if (window.scrollY > 30) {
            logo.style.width = "100px";
            logo.style.height = "100px";
            navbar.style.height = "8.5vh";
        } else {
            navbar.style.height = "12.5vh";
            logo.style.width = "150px";
            logo.style.height = "150px";
        }
    }
}


