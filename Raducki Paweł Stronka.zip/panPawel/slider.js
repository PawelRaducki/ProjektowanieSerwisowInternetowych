document.addEventListener("DOMContentLoaded", function() {
    // Tablica z adresami URL obrazów
    var images = [
        "http://localhost/Kawiarnia/assets/Image1.jpg",
        "http://localhost/Kawiarnia/assets/Image2.jpg"
    ];
    

    var texts = [
        "Zamów ciasto",
        "Potrzebujesz menu?"
    ];

    var paragraphs = [
        "Zamów u nas ciasta z naszej oferty",
        "Możesz je znaleść na naszej stronie!"
    ];

    var linkText = [
        "ZAMÓW CIASTO",
        "ZOBACZ MENU"
    ];

    var linkUrls = [
        "Shop.php",
        "menu.html"
    ];

    var currentIndex = 0;
    var maxIndex = images.length - 1;
    var block1 = document.querySelector('.block1');
    var textElements = document.querySelectorAll('.order-text');
    var paragraphElements = document.querySelectorAll('.order-paragraph');
    var linkElements = document.querySelectorAll('.order-link');
    var imageElements = document.querySelectorAll('.order-img');

    function changeSlide() {
        block1.style.backgroundImage = "url(" + images[currentIndex] + ")";
        
        if (currentIndex === 1) {
            for (var i = 0; i < imageElements.length; i++) {
                imageElements[i].style.display = "none";
            }
        } else {
            for (var i = 0; i < imageElements.length; i++) {
                imageElements[i].style.display = "block";
            }
        }

        for (var i = 0; i < textElements.length; i++) {
            textElements[i].textContent = texts[currentIndex];
            paragraphElements[i].textContent = paragraphs[currentIndex];
            linkElements[i].textContent = linkText[currentIndex];
            linkElements[i].href = linkUrls[currentIndex];
        }
        
        currentIndex = (currentIndex === maxIndex) ? 0 : currentIndex + 1;
    }

    var interval = setInterval(changeSlide, 5000);
});

