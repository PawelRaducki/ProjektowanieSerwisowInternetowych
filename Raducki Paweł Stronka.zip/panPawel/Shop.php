<!DOCTYPE html>
<html lang="pl-PL">
<head>
    <meta name="title" content="Kawiarnia basic">
    <meta name="description" content="Kolejna typowa kawiarnia w twojej okolicy!">
    <meta name="keywords" content="kawiarnia,kawa,ciasto,piwo,restauracja,jedzenie,picie,tort">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kawiarnia BASIC | Kawa i ciasta</title>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="ShopStyle.css">
    <script src="navScroll.js" defer></script>
    <script src="shoppingcart.js" defer></script>
    <script src="hamburger.js" defer></script>
</head>
<body>
    <!-- navigation -->
    <div class="navbar">
        <div class="logo-box">
            <a href="index.html">
                <img src="./assets/Logo.png" alt="Basic logo" class="logo">
            </a>
        </div>

        <button class="hamburger">
                <div class="bar"></div>
            </button>

            <div class="mobile-nav">
                <a href="menu.html">Menu</a>
                <a href="reservation.php">Rezerwacja</a>
                <a href="#">Sklep</a>
                <a href="about.html">O nas</a>
                <a href="contact.php">Kontakt</a>
                <div class="cart">
                    <a href="#" class="mobile-nav-cart">
                        <img src="./assets/shopping-cart-svgrepo-com.svg" alt="cart" width="50px" class="cart-ico">
                        <p class="cart-number">0</p>
                    </a>
                </div>
            </div>
        </div>
        
        <div class="buttons">
            <a href="menu.html">Menu</a>
            <a href="reservation.php">Rezerwacja</a>
            <a href="#">Sklep</a>
            <a href="about.html">O nas</a>
            <a href="contact.html">Kontakt</a>
            <div class="cart">
            <a href="#">
                <img src="./assets/shopping-cart-svgrepo-com.svg" alt="cart" width="50px" class="cart-ico">
                <p class="cart-number">0</p>
            </a>
        </div>
    </div>
    </div>
    <!-- all other things on the website -->
    <div class="main">
        <!-- cafe shop page -->
        <div class="shop-block">
            <div class="shop-block-title-container">
                <h1 class="shop-block-title">Sklep</h1>
            </div>

            <div class="product-container"> 
                <?php
                $servername = "localhost";
                $username = "root";
                $password = "";
                $dbname = "Kawiarnia";
                
                $conn = new mysqli($servername, $username, $password, $dbname);
                
                if ($conn->connect_error) {
                    die("Connection failed: " . $conn->connect_error);
                }
                
                $produkty = "SELECT ProduktyID, Nazwa, Cena, obraz FROM produkty";
                $wynik1 = mysqli_query($conn, $produkty);
                while($wiersz1 = mysqli_fetch_array($wynik1)) {
                    echo '<div class="product">';
                    echo '<img src="' . $wiersz1[3] . '" alt="zdjecie" class="product-img">';
                    echo '<h1>' . $wiersz1[1] . '</h1>';
                    echo '<p>' . $wiersz1[2] . ' zł</p>';
                    echo '<input type="number" id="quantity" name="quantity" min="1" value="1">';
                    echo '<button onclick="addToCart()">Dodaj</button>';
                    echo '</div>';
                }


                ?>
        </div>

        
    </div>

        <!-- end of site and footer-->
        <div class="footer">
            <div class="background-img">
                <div class="blur">
                    <div class="logo-box">
                        <img src="./assets/Logo.png" alt="Basic logo" class="logo">
                        <div class="logo-texts">
                            <h3 class="logo-text">Kawiarnia BASIC</h3>
                            <p class="logo-paragraph">Wszędzie są takie same. A my niczym się nie wyrózniamy!</p>
                        </div>
                    </div>
                        <div class="footer-links">
                            <h1>Główna</h1>
                            <a href="index.html">BASIC</a>
                            <a href="menu.html">Menu</a>
                            <a href="reservation.php">Rezerwacje</a>
                            <a href="#">Zamówienia</a>
                            <a href="#">Sklep</a>
                            <a href="#">O nas</a>
                            <a href="#">Polityka Prywatności</a>
                            <a href="">Regulamin</a>
                        </div>
                        <div class="footer-location">
                            <h1>Lokalizacja</h1>
                            <p>Ulica jakaś tam 1/3</p>
                            <p>Miastowo, 00-000</p>
                        </div>
                        <div class="lorem">
                            <h1>Lorem ipsum</h1>
                            <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Blanditiis fuga obcaecati, accusamus aliquam nam, vitae repellendus iusto temporibus ut, amet placeat!</p>
                        </div>
                        <p class="credit">stronę stworzył Paweł Raducki</p>
                    </div>
                </div>
            </div>
        </div>
    </div>

</body>
</html>