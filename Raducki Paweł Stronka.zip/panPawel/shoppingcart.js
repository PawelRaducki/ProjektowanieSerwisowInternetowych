function addToCart() {
    var productName = document.querySelector('.product h1').innerText;
    var productPrice = parseFloat(document.querySelector('.product p').innerText);
    var quantity = parseInt(document.querySelector('.product input').value);
    var totalPrice = productPrice * quantity;

    var product = {
        name: productName,
        price: productPrice,
        quantity: quantity,
        totalPrice: totalPrice
    };

    var cart = JSON.parse(localStorage.getItem('cart')) || [];
    cart.push(product);
    localStorage.setItem('cart', JSON.stringify(cart));
    updateCartNumber(cart.length);
}

function updateCartNumber(quantity) {
    var cartNumber = document.querySelector('.cart-number');
    cartNumber.innerText = quantity;
}

window.onload = function() {
    var cart = JSON.parse(localStorage.getItem('cart')) || [];
    updateCartNumber(cart.length);
};
