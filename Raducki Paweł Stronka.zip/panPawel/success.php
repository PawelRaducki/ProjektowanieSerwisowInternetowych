<!DOCTYPE html>
<html lang="pl-PL">
<head>
    <meta name="title" content="Kawiarnia basic">
    <meta name="description" content="Kolejna typowa kawiarnia w twojej okolicy!">
    <meta name="keywords" content="kawiarnia,kawa,ciasto,piwo,restauracja,jedzenie,picie,tort">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kawiarnia BASIC | Kawa i ciasta</title>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="reservationStyle.css">
    <script src="navScroll.js" defer></script>
    <script src="shoppingcart.js" defer></script>
    <script src="hamburger.js" defer></script>
</head>
<body>
    <!-- navigation -->
    <div class="navbar">
        <div class="logo-box">
            <a href="index.html">
                <img src="./assets/Logo.png" alt="Basic logo" class="logo">
            </a>
        </div>

        <button class="hamburger">
                <div class="bar"></div>
            </button>

            <div class="mobile-nav">
                <a href="menu.html">Menu</a>
                <a href="reservation.php">Rezerwacja</a>
                <a href="Shop.php">Sklep</a>
                <a href="about.html">O nas</a>
                <a href="contact.php">Kontakt</a>
                <div class="cart">
                    <a href="#" class="mobile-nav-cart">
                        <img src="./assets/shopping-cart-svgrepo-com.svg" alt="cart" width="50px" class="cart-ico">
                        <p class="cart-number">0</p>
                    </a>
                </div>
            </div>
        </div>
        
        <div class="buttons">
            <a href="menu.html">Menu</a>
            <a href="#">Rezerwacja</a>
            <a href="#">Sklep</a>
            <a href="#">O nas</a>
            <a href="contact.html">Kontakt</a>
            <div class="cart">
            <a href="#">
                <img src="assets/shopping-cart-svgrepo-com.svg" alt="cart" width="50px" class="cart-ico">
                <p class="cart-number">0</p>
            </a>
        </div>
    </div>
    </div>
    <!-- all other things on the website -->
    <div class="main">
        <div class="reservation-block">
            <h1 class="reservation-Text-success" style="font: size 48px;">Sukces!</h2>
            <p class="reservation-Paragraph-success">Rezerwacja miejsca przeszla pomyslnie!</p>
        </div>

    </div>

        <!-- end of site and footer-->
        <div class="footer">
            <div class="background-img">
                <div class="blur">
                    <div class="logo-box">
                        <img src="./assets/Logo.png" alt="Basic logo" class="logo">
                        <div class="logo-texts">
                            <h3 class="logo-text">Kawiarnia BASIC</h3>
                            <p class="logo-paragraph">Wszędzie są takie same. A my niczym się nie wyrózniamy!</p>
                        </div>
                    </div>
                        <div class="footer-links">
                            <h1>Główna</h1>
                            <a href="index.html">BASIC</a>
                            <a href="menu.html">Menu</a>
                            <a href="#">Rezerwacje</a>
                            <a href="#">Zamówienia</a>
                            <a href="#">Sklep</a>
                            <a href="#">O nas</a>
                            <a href="#">Polityka Prywatności</a>
                            <a href="">Regulamin</a>
                        </div>
                        <div class="footer-location">
                            <h1>Lokalizacja</h1>
                            <p>Ulica jakaś tam 1/3</p>
                            <p>Miastowo, 00-000</p>
                        </div>
                        <div class="lorem">
                            <h1>Lorem ipsum</h1>
                            <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Blanditiis fuga obcaecati, accusamus aliquam nam, vitae repellendus iusto temporibus ut, amet placeat!</p>
                        </div>
                        <p class="credit">stronę stworzył Paweł Raducki</p>
                    </div>
                </div>
            </div>
        </div>
    </div>

</body>
</html>