<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "Kawiarnia";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Sprawdzenie, czy formularz został przesłany
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Przechwytywanie danych z formularza
    $imieNazwisko = $_POST['name'];
    $email = $_POST['email'];
    $content = $_POST['content'];

    // Sprawdzenie, czy klient o podanym adresie e-mail istnieje już w bazie danych
    $sqlCheckClient = "SELECT KlientID FROM Klienci WHERE Email = '$email'";
    $resultCheckClient = $conn->query($sqlCheckClient);

    if ($resultCheckClient->num_rows > 0) {
        $rowClient = $resultCheckClient->fetch_assoc();
        $klientID = $rowClient["KlientID"];
    } else {
        // Dodanie nowego klienta do bazy danych
        $sqlAddClient = "INSERT INTO Klienci (ImieNazwisko, Email) VALUES ('$imieNazwisko', '$email')";
        if ($conn->query($sqlAddClient) === TRUE) {
            $klientID = $conn->insert_id;
        } else {
            echo "Błąd: " . $sqlAddClient . "<br>" . $conn->error;
        }
    }

    // Dodanie treści wiadomości do tabeli Kontakt wraz z identyfikatorem klienta
    $sqlAddContact = "INSERT INTO Kontakt (KlientID, Tresc) VALUES ('$klientID', '$content')";

    if ($conn->query($sqlAddContact) === TRUE) {
        echo "Wiadomość została pomyślnie wysłana.";
    } else {
        echo "Błąd: " . $sqlAddContact . "<br>" . $conn->error;
    }

    // Zamknięcie połączenia z bazą danych
    $conn->close();
}
?>



<!DOCTYPE html>
<html lang="pl-PL">
<head>
    <meta name="title" content="Kawiarnia basic">
    <meta name="description" content="Kolejna typowa kawiarnia w twojej okolicy!">
    <meta name="keywords" content="kawiarnia,kawa,ciasto,piwo,restauracja,jedzenie,picie,tort">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kawiarnia BASIC | Kawa i ciasta</title>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="contactstyle.css">
    <script src="navScroll.js" defer></script>
    <script src="shoppingcart.js" defer></script>
    <script src="hamburger.js" defer></script>
</head>
<body>
    <!-- navigation -->
    <div class="navbar">
        <div class="logo-box">
            <a href="index.html">
                <img src="./assets/Logo.png" alt="Basic logo" class="logo">
            </a>
        </div>

        <button class="hamburger">
                <div class="bar"></div>
            </button>

            <div class="mobile-nav">
                <a href="menu.html">Menu</a>
                <a href="reservation.php">Rezerwacja</a>
                <a href="Shop.php">Sklep</a>
                <a href="about.html">O nas</a>
                <a href="#">Kontakt</a>
                <div class="cart">
                    <a href="#" class="mobile-nav-cart">
                        <img src="./assets/shopping-cart-svgrepo-com.svg" alt="cart" width="50px" class="cart-ico">
                        <p class="cart-number">0</p>
                    </a>
                </div>
            </div>
        </div>
        
        <div class="buttons">
            <a href="menu.html">Menu</a>
            <a href="reservation.php">Rezerwacja</a>
            <a href="Shop.php">Sklep</a>
            <a href="about.html">O nas</a>
            <a href="#">Kontakt</a>
            <div class="cart">
            <a href="#">
                <img src="./assets/shopping-cart-svgrepo-com.svg" alt="cart" width="50px" class="cart-ico">
                <p class="cart-number">0</p>
            </a>
        </div>
    </div>
    </div>
    <!-- all other things on the website -->
    <div class="main">
        <!-- cafe contact page -->
            <div class="adress-number-block">
                <div class="adress">
                    <h1>Adres:</h1>
                    <p>Miastowo 00-000</p>
                    <p>Ulica jakaś tam 1/3</p>
                </div>
                <div class="number">
                    <h1>Kontakt:</h1>
                    <p>Rezerwacja lokalu</p>
                    <h3>000000000</h3>
                </div>
            </div>
            <div class="contact-form">

                <h1 class="form-text">Skontaktuj sie z nami</h1>
                <form action="contact.php"  method="post">
                    <div class="contact-form-container">
                        <input type="text" class="form-name" id="name" name="name" placeholder="Imie">
                        <input type="text" class="form-email" id="email" name="email" placeholder="Email">
                    </div>
                    <div class="contact-form-container2"> 
                        <textarea type="text" class="form-content" id="content" name="content" rows="4" cols="50" maxlength="400" placeholder="Tresc wiadomości"></textarea>
                        <input type="submit" class="form-submit" value="Wyslij">
                    </div>

                    
                  </form> 
            </div>
        </div>

        <!-- end of site and footer-->
        <div class="footer">
            <div class="background-img">
                <div class="blur">
                    <div class="logo-box">
                        <img src="./assets/Logo.png" alt="Basic logo" class="logo">
                        <div class="logo-texts">
                            <h3 class="logo-text">Kawiarnia BASIC</h3>
                            <p class="logo-paragraph">Wszędzie są takie same. A my niczym się nie wyrózniamy!</p>
                        </div>
                    </div>
                        <div class="footer-links">
                            <h1>Główna</h1>
                            <a href="index.html">BASIC</a>
                            <a href="menu.html">Menu</a>
                            <a href="reservation.php">Rezerwacje</a>
                            <a href="#">Zamówienia</a>
                            <a href="Shop.php">Sklep</a>
                            <a href="about.html">O nas</a>
                            <a href="#">Polityka Prywatności</a>
                            <a href="#">Regulamin</a>
                        </div>
                        <div class="footer-location">
                            <h1>Lokalizacja</h1>
                            <p>Ulica jakaś tam 1/3</p>
                            <p>Miastowo, 00-000</p>
                        </div>
                        <div class="lorem">
                            <h1>Lorem ipsum</h1>
                            <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Blanditiis fuga obcaecati, accusamus aliquam nam, vitae repellendus iusto temporibus ut, amet placeat!</p>
                        </div>
                        <p class="credit">stronę stworzył Pan Paweł Raducki</p>
                    </div>
                </div>
            </div>
        </div>
    </div>

</body>
</html>